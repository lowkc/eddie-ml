import os, sys
from ase.io import read, write, extxyz
from ase import neighborlist, Atoms
from scipy import sparse

def split_xyz_into_dimers(atoms, mult=0.8):
    cutoff = neighborlist.natural_cutoffs(atoms, mult)
    neighborList = neighborlist.NeighborList(cutoff, self_interaction=False, bothways=True)
    neighborList.update(atoms)
    matrix = neighborList.get_connectivity_matrix(sparse=True)
    n_components, component_list = sparse.csgraph.connected_components(matrix)
    if n_components != 2:
        print("Error! Number of molecules does not equal 2. Please check your xyz file.")
    
    dimer0_idx = [ i for i in range(len(component_list)) if component_list[i] == 0 ]
    dimer1_idx = [ i for i in range(len(component_list)) if component_list[i] == 1 ]
    
    dimer0_pos = atoms.positions[dimer0_idx]
    dimer1_pos = atoms.positions[dimer1_idx]
    
    dimer0_elems = atoms.get_chemical_symbols()[dimer0_idx[0]:dimer0_idx[-1]+1]
    dimer1_elems = atoms.get_chemical_symbols()[dimer1_idx[0]:dimer1_idx[-1]+1]
    
    dimer0 = Atoms(''.join(i for i in dimer0_elems), positions=dimer0_pos)
    dimer1 = Atoms(''.join(i for i in dimer1_elems), positions=dimer1_pos)
    
    return dimer0, dimer1

def gen_trimers(dimerfilename, outfile):
    xyzfile = read(dimerfilename, ':')
    m1 = xyzfile[0]
    dimer = xyzfile[1]
    m2, m3 = split_xyz_into_dimers(dimer)
    basename = os.path.basename(dimerfilename)
    write(f'{basename}', [m1, m2, m3], plain=True)

if __name__ == "__main__":
    gen_trimers(sys.argv[1], outfile=None)    
